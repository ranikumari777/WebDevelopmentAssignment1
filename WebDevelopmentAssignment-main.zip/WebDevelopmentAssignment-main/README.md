Name - Pallavi Kumari 
Class - MCA (C)
Roll.no. - 202410116100139
